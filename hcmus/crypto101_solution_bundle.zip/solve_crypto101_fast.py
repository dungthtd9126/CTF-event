#!/usr/bin/env python3
"""
Fast verifier for HCMUS CTF crypto101.

The heavy lattice part is documented in crypto101_writeup.md and implemented in
solve_crypto101.py. This script uses the recovered target EC point from that
attack and performs the final MD5/AES decryption so the flag can be checked
quickly.
"""
import ast
import sys
from hashlib import md5
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import unpad
    def aes_ecb_decrypt(key, ct):
        return unpad(AES.new(key, AES.MODE_ECB).decrypt(ct), 16)
except ModuleNotFoundError:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    def unpad(data, block=16):
        n = data[-1]
        if not 1 <= n <= block or data[-n:] != bytes([n]) * n:
            raise ValueError("bad padding")
        return data[:-n]
    def aes_ecb_decrypt(key, ct):
        decryptor = Cipher(algorithms.AES(key), modes.ECB(), backend=default_backend()).decryptor()
        return unpad(decryptor.update(ct) + decryptor.finalize(), 16)

TARGET_X = 7443223711502152433373342360595344398914949896728196514983978636255197132704917982363276468344885358095327301004534674480319464911406214468633264745609328955542954078285153354680969400995708865106408897602195971852982855669192732054845973632256300801762171364430820268705263546692346432460225449914505897602
TARGET_Y = 61280213507446684380668367019542809292838327738746403887466185879912210910077452868556480646363615335837615964809536450399083378015929264836826301689186213942681368872611461665120467457096290686389050493480429239162013525408007099313043968343530851453948723062668617947908831351779666472403454219134200203788


def main(path: str) -> None:
    with open(path, 'r', encoding='utf-8') as f:
        _px_mod_p = int(f.readline())
        _points = ast.literal_eval(f.readline())
        ct = bytes.fromhex(f.readline().strip())

    # Sage's str(E(x, y)) is projective: "(x : y : 1)".
    sage_point_str = f"({TARGET_X} : {TARGET_Y} : 1)"
    key = md5(sage_point_str.encode()).digest()
    flag = aes_ecb_decrypt(key, ct)
    print(flag.decode())


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(f"usage: {sys.argv[0]} public/output.txt", file=sys.stderr)
        raise SystemExit(2)
    main(sys.argv[1])
