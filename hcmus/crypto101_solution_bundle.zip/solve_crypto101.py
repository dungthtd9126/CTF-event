#!/usr/bin/env python3
"""
Solve script for crypto101.

Dependencies:
    python3 -m pip install cypari2 fpylll cysignals cryptography sympy

Usage:
    python3 solve_crypto101.py public/output.txt
"""
import ast
import hashlib
import random
import sys
from math import gcd

from cypari2 import Pari
from fpylll import BKZ, CVP, Enumeration, EvaluatorStrategy, GSO, IntegerMatrix, LLL
from sympy import Matrix
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend


def iroot(n: int, k: int) -> int:
    lo, hi = 0, 1 << ((n.bit_length() + k - 1) // k)
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if mid**k <= n:
            lo = mid
        else:
            hi = mid
    return lo


def parse_output(path: str):
    lines = open(path, "r", encoding="utf-8").read().strip().splitlines()
    x0 = int(lines[0])
    R = ast.literal_eval(lines[1])
    ct = bytes.fromhex(lines[2])
    return x0, R, ct


def recover_modulus(R):
    G = 0
    for i in range(0, min(60, len(R) - 2), 3):
        pts = R[i : i + 3]
        xs = [P[0] for P in pts]
        vs = [y * y - x * x * x for x, y in pts]
        # det [[x_i, 1, y_i^2-x_i^3]] is 0 mod p^4.
        D = xs[0] * (vs[1] - vs[2]) - xs[1] * (vs[0] - vs[2]) + xs[2] * (vs[0] - vs[1])
        G = abs(D) if G == 0 else gcd(G, abs(D))
    p = iroot(G, 4)
    assert p**4 == G
    return p, G


def recover_curve(R, N):
    for i in range(len(R)):
        for j in range(i + 1, len(R)):
            x1, y1 = R[i]
            x2, y2 = R[j]
            if gcd(x1 - x2, N) == 1:
                v1 = (y1 * y1 - x1 * x1 * x1) % N
                v2 = (y2 * y2 - x2 * x2 * x2) % N
                a = ((v1 - v2) * pow(x1 - x2, -1, N)) % N
                b = (v1 - a * x1) % N
                assert all((y * y - x * x * x - a * x - b) % N == 0 for x, y in R[:20])
                return a, b
    raise RuntimeError("could not find invertible x difference")


class EC:
    def __init__(self, a, b, N):
        self.a = a
        self.b = b
        self.N = N
        self.O = (0, 1, 0)

    def isO(self, P):
        return P[2] % self.N == 0

    def dbl(self, P):
        N, a = self.N, self.a
        if self.isO(P):
            return self.O
        X1, Y1, Z1 = P
        if Y1 % N == 0:
            return self.O
        XX = X1 * X1 % N
        YY = Y1 * Y1 % N
        YYYY = YY * YY % N
        ZZ = Z1 * Z1 % N
        S = (2 * (((X1 + YY) % N) ** 2 - XX - YYYY)) % N
        M = (3 * XX + a * (ZZ * ZZ % N)) % N
        T = (M * M - 2 * S) % N
        return (T, (M * (S - T) - 8 * YYYY) % N, (((Y1 + Z1) % N) ** 2 - YY - ZZ) % N)

    def add(self, P, Q):
        N = self.N
        if self.isO(P):
            return Q
        if self.isO(Q):
            return P
        X1, Y1, Z1 = P
        X2, Y2, Z2 = Q
        Z1Z1 = Z1 * Z1 % N
        Z2Z2 = Z2 * Z2 % N
        U1 = X1 * Z2Z2 % N
        U2 = X2 * Z1Z1 % N
        S1 = Y1 * Z2 % N * Z2Z2 % N
        S2 = Y2 * Z1 % N * Z1Z1 % N
        H = (U2 - U1) % N
        r = (2 * (S2 - S1)) % N
        if H == 0:
            return self.dbl(P) if r == 0 else self.O
        I = (2 * H) % N
        I = I * I % N
        J = H * I % N
        V = U1 * I % N
        X3 = (r * r - J - 2 * V) % N
        Y3 = (r * (V - X3) - 2 * S1 % N * J) % N
        Z3 = ((((Z1 + Z2) % N) ** 2 - Z1Z1 - Z2Z2) % N) * H % N
        return (X3, Y3, Z3)

    def neg(self, P):
        if self.isO(P):
            return P
        X, Y, Z = P
        return (X, (-Y) % self.N, Z)

    def mul(self, P, k):
        if k < 0:
            return self.mul(self.neg(P), -k)
        R = self.O
        Q = P
        while k:
            if k & 1:
                R = self.add(R, Q)
            Q = self.dbl(Q)
            k >>= 1
        return R

    def affine(self, P):
        if self.isO(P):
            return None
        X, Y, Z = P
        zi = pow(Z, -1, self.N)
        z2 = zi * zi % self.N
        return X * z2 % self.N, Y * z2 % self.N * zi % self.N

    def formal_t(self, P):
        X, Y, Z = P
        return (-X * Z * pow(Y, -1, self.N)) % self.N


def curve_order_mod_p(a, b, p):
    pari = Pari()
    pari.allocatemem(512 * 1024 * 1024)
    E = pari.ellinit([a % p, b % p], p)
    return int(pari.ellcard(E))


def recover_logs(R, ec, n0, p):
    h = []
    for x, y in R:
        K = ec.mul((x, y, 1), n0)
        t = ec.formal_t(K)
        assert t % p == 0
        h.append((t // p) % (p**3))
    return h


def recover_columns(h, B_bound=255, hidden_dim=24):
    """Recover the 24 hidden coefficient columns from h = C * alpha mod p^3."""
    Qmod = None  # supplied by h values' modulus through closure below
    raise RuntimeError("Use recover_columns_mod")


def recover_columns_mod(h, Qmod, B_bound=255, hidden_dim=24):
    m = len(h)
    n = hidden_dim
    piv = next(i for i, v in enumerate(h) if gcd(v, Qmod) == 1)
    perm = [piv] + [i for i in range(m) if i != piv]
    hp = [h[i] for i in perm]
    inv0 = pow(hp[0], -1, Qmod)

    L0 = IntegerMatrix(m, m)
    L0[0, 0] = Qmod
    for i in range(1, m):
        L0[i, 0] = (-hp[i] * inv0) % Qmod
        L0[i, i] = 1

    print("[*] LLL on orthogonal lattice")
    LLL.reduction(L0, delta=0.99)
    lengths = []
    for i in range(m):
        row = [int(L0[i, j]) for j in range(m)]
        lengths.append((sum(x * x for x in row), i))
    lengths.sort()

    U = []
    for _, i in lengths[: m - n]:
        row = [int(L0[i, j]) for j in range(m)]
        orig = [0] * m
        for j, val in enumerate(row):
            orig[perm[j]] = val
        U.append(orig)

    print("[*] integer kernel and BKZ")
    pari = Pari()
    pari.allocatemem(512 * 1024 * 1024)
    s = "[" + ";".join(",".join(str(x) for x in row) for row in U) + "]"
    K = pari.matkerint(pari(s))  # 120 x 24 matrix, columns are a Z-kernel basis
    r, d = map(int, pari.matsize(K))
    basis = []
    for j in range(d):
        basis.append([int(K[i, j]) for i in range(r)])

    L = IntegerMatrix(d, m)
    for i, row in enumerate(basis):
        for j, val in enumerate(row):
            L[i, j] = val
    LLL.reduction(L, delta=0.99)
    BKZ.reduction(L, BKZ.Param(block_size=30))
    red_basis = [[int(L[i, j]) for j in range(m)] for i in range(d)]

    print("[*] enumerate short [0,255] vectors")
    M = GSO.Mat(L)
    M.update_gso()
    # The original columns have expected norm^2 = 120 * E[byte^2] ~= 2.6e6.
    # Increase radius until 24 valid columns are found.
    for radius in [2_600_000, 3_000_000, 4_000_000, 6_000_000, 8_000_000, 12_000_000]:
        enum = Enumeration(M, nr_solutions=300000, strategy=EvaluatorStrategy.BEST_N_SOLUTIONS)
        sols = enum.enumerate(0, d, radius, 0)
        cols = []
        for _, coeffs in sols:
            coeffs = [int(round(c)) for c in coeffs]
            vec = [0] * m
            for i, c in enumerate(coeffs):
                if c:
                    row = red_basis[i]
                    for j in range(m):
                        vec[j] += c * row[j]
            for vv in (vec, [-x for x in vec]):
                if all(0 <= x <= B_bound for x in vv) and any(vv):
                    if vv not in cols:
                        cols.append(vv)
        print(f"    radius={radius}: {len(cols)} columns")
        if len(cols) >= n:
            # Sort by norm and keep the 24 shortest; these are the hidden random byte columns.
            cols.sort(key=lambda v: sum(x * x for x in v))
            return cols[:n]
    raise RuntimeError("failed to recover all hidden columns")


def solve_linear_combination(cols, R, ec, group_order):
    # cols: 24 vectors, each length 120. Crows[i][j] = byte coefficient of Q_j in R_i.
    Crows = [[cols[j][i] for j in range(len(cols))] for i in range(len(R))]
    random.seed(1337)
    one = Matrix([1] * len(cols))
    for _ in range(10000):
        sample = random.sample(range(len(R)), len(cols))
        A = Matrix([Crows[i] for i in sample]).T
        det = int(A.det())
        if gcd(det, group_order) == 1:
            lam = [int(x) % group_order for x in (A.inv_mod(group_order) * one)]
            assert all(sum(lam[t] * Crows[sample[t]][j] for t in range(len(cols))) % group_order == 1 for j in range(len(cols)))
            S = ec.O
            for l, idx in zip(lam, sample):
                S = ec.add(S, ec.mul((R[idx][0], R[idx][1], 1), l))
            return ec.affine(S)
    raise RuntimeError("could not find invertible row subset")


def aes_ecb_decrypt(key, ct):
    dec = Cipher(algorithms.AES(key), modes.ECB(), backend=default_backend()).decryptor()
    pt = dec.update(ct) + dec.finalize()
    pad = pt[-1]
    if not (1 <= pad <= 16 and pt.endswith(bytes([pad]) * pad)):
        return None
    return pt[:-pad]


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "public/output.txt"
    x0, R, ct = parse_output(path)

    p, N = recover_modulus(R)
    print(f"[+] p = {p}")
    a, b = recover_curve(R, N)
    print("[+] recovered curve coefficients")

    n0 = curve_order_mod_p(a, b, p)
    print(f"[+] #E(F_p) = {n0}")
    ec = EC(a, b, N)

    h = recover_logs(R, ec, n0, p)
    cols = recover_columns_mod(h, p**3, 255, 24)
    print("[+] recovered hidden byte matrix columns")

    S = solve_linear_combination(cols, R, ec, n0 * p**3)
    x, y = S
    sage_point_str = f"({x} : {y} : 1)"
    key = hashlib.md5(sage_point_str.encode()).digest()
    flag = aes_ecb_decrypt(key, ct)
    if flag is None:
        raise RuntimeError("bad key/point string")
    print(f"[+] point = {sage_point_str}")
    print(f"[+] flag = {flag.decode()}")


if __name__ == "__main__":
    main()
