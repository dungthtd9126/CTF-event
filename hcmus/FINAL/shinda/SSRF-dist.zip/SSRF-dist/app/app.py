from flask import Flask, request, jsonify
import pycurl

app = Flask(__name__)

@app.route('/fetch', methods=['POST'])
def fetch_url():
    data = request.get_json()
    url = data.get('url')
    if not url:
        return jsonify({'error': 'No URL provided'}), 400
    c = pycurl.Curl()
    c.setopt(c.URL, url)
    try:
        c.perform()
    except Exception:
        pass
    finally:
        c.close()
    return jsonify({'message': 'Request completed'})

if __name__ == '__main__':
    app.run(host='0.0.0.0')
