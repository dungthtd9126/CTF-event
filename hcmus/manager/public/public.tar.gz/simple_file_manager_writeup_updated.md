# simple_file_manager write-up

## Summary

This challenge is a heap UAF in a small file-manager binary.

The key bug is in `read_file()`: it frees the selected file and any extension chunks, but it **does not clear the pointer** stored in the current directory slot. That gives a stable dangling pointer and lets us repeatedly reinterpret and free recycled heap chunks.

The final exploit strategy is:

1. Create a stale file pointer with `read_file()`.
2. Recycle that freed chunk as a directory with `mkdir()`.
3. Use the stale pointer to read far past the recycled directory and leak heap + libc.
4. Reclaim another stale directory chunk as a fake directory.
5. Build **two overlapping fake 0xa0 chunks** inside it.
6. Use those overlapping fake chunks for a **malloc-only tcache poison**.
7. Write `_IO_list_all = fake_FILE`.
8. Exit, so glibc walks `_IO_list_all` and dispatches into a fake `_IO_wfile_jumps` vtable whose slot points to `system`.

A corrected local exploit script is included separately and works on the host runtime. It also contains a `leak235` path for the pinned Ubuntu 22.04 glibc 2.35 deployment target.

---

## Binary overview

Global state:

```c
int cwd;
struct dir *fs[8];
```

Directory layout:

```c
struct dir {
    char name[0x10];
    struct file *files[16];
};
```

File layout:

```c
struct file {
    uint32_t mode;
    uint32_t checksum;
    uint64_t size;
    struct ext *next;
    char data[];
};
```

So file user data begins at `file + 0x18`.

### Allocations

`write_file()` allocates:

- primary chunk: `malloc(min(size, 0x1000) + 0x18)`
- extension chunks: `malloc(chunk + 0x8)`

`mkdir()` allocates:

- `calloc(1, 0x90)`

That means a file of size `0x78` gives a `0x90` user allocation, which is a `0xa0`-size heap chunk after metadata. This is the same size-class later used by `mkdir()`.

---

## Vulnerability

The bug is in `read_file()`:

```c
f = current_dir->files[idx];
print fields;
write data;
free(f);
free(extra_chunks);
// missing: current_dir->files[idx] = NULL;
```

That leaves a dangling file pointer in the directory slot.

From that point on, if the freed chunk is reallocated for something else, reading the stale slot treats the new object as a `struct file`:

- `mode` is read from offset `0x0`
- `checksum` from `0x4`
- `size` from `0x8`
- `next` from `0x10`
- data is printed from `0x18`
- then the object is freed again

So we get both:

- **type confusion / OOB read**, and
- **use-after-free / double-free style heap manipulation**

---

## Leak stage

### 1. Recycle a freed 0xa0 chunk as a directory

On the target runtime, the stable layout is:

- one target `0xa0` file
- one guard
- seven filler `0xa0` files
- one large file
- one guard

Then:

1. free the 7 fillers to fill `tcache[0xa0]`
2. free the large file so its main chunk goes to unsorted
3. free the target file while `tcache[0xa0]` is full
4. call `mkdir(1)` so the freed target chunk is reused as a directory
5. read the stale slot again

The stale file pointer now points to a recycled directory. Because `read_file()` still interprets it as a file, its `size` field comes from directory memory, so it prints a long chunk of heap data and leaks both heap metadata and the unsorted-bin pointer.

### 2. Recover heap + libc

For the pinned Ubuntu 22.04 glibc 2.35 runtime, the exploit script uses:

```python
heap_page = u64(leak[0xc8:0xd0]) << 12
libc_base = u64(leak[0x528:0x530]) - 0x21a300
```

That yields deterministic addresses for the key recycled chunks:

```python
F2       = heap_page + 0x340
fake_B   = F2 + 0x20
fake_A   = F2 + 0x40
BIG      = heap_page + 0x880
```

`BIG` is later reused to store the fake FILE / wide-data / fake vtable blob.

---

## Why the first endgame was brittle

The original exploit attempt used a `mkdir()` / `calloc()`-based poison step to plant a safe-linked tcache fd.

That worked on one local environment but was not reliable across glibc behavior differences. The corrected solve avoids that by switching to a **malloc-only overlapping fake chunk poison**.

This is the important fix.

---

## Final arbitrary write: overlapping fake chunks

After leaking addresses, we reclaim a stale chunk as a fake directory and make it contain two overlapping fake `0xa0` chunks:

- `B = F2 + 0x20`
- `A = F2 + 0x40`

The fake directory payload is:

```python
payload[0x00:0x08] = p64(0xA1)     # B size at F2+0x18
payload[0x08:0x10] = p64(fake_B)   # fake dir slot -> B
payload[0x10:0x18] = p64(0)
payload[0x18:0x20] = p64(0)
payload[0x20:0x28] = p64(0xA1)     # A size at F2+0x38
payload[0x28:0x30] = p64(fake_A)   # fake dir slot -> A
payload[0x30:0x38] = p64(0)
payload[0x38:0x40] = p64(0)
```

The important geometry is:

- allocating `B` returns chunk `B`
- file data for `B` starts at `B + 0x18`
- that overlaps `A - 0x8`

So if `A` is already in tcache, writing into `B` lets us overwrite `A->next` while `A` is still a freed tcache entry.

### Malloc-only poison sequence

1. free `A`
2. free `B`
3. allocate `B` again
4. while filling `B`'s file data, overwrite the safe-linked `next` pointer stored inside freed `A`
5. allocate once more to get `A`
6. allocate again to get the poisoned target address

This gives a clean arbitrary write without depending on `calloc()` behavior.

---

## FSOP endgame

We reuse the freed large chunk `BIG` and fill it with a fake FILE structure, fake wide-data, fake lock, and fake vtable.

The fake vtable entry at offset `+0x68` is set to `system`.

Then we use the arbitrary write to place:

```python
_IO_list_all = fake_file
```

Finally, we choose menu option `6` to exit.

During process teardown, glibc flushes `_IO_list_all`, follows our fake FILE, takes the wide-file path, and dispatches through our fake vtable entry into `system`.

The fake FILE begins with the string:

```python
b" sh\x00..."
```

so the call becomes effectively:

```c
system(" sh")
```

After that the exploit sends:

```sh
echo PWNED; cat flag; exit
```

and reads back the flag.

---

## Local result

The corrected exploit succeeds locally and prints:

```text
PWNED
HCMUS_CTF{fake_flag}
```

---

## Notes on the provided exploit script

The updated script supports two strategies:

- `host_maps`: local convenience path that reads `/proc/<pid>/maps`
- `leak235`: target-style path that derives heap and libc from the stale read leak

On the container I used here, `host_maps` is directly verified. The same script also contains the corrected `leak235` path and the fixed malloc-only poison stage for the pinned Ubuntu 22.04 deployment.

---

## Exploit script

Use the updated script file:

```bash
python3 simple_file_manager_local_exploit_fixed.py
```

For a local bundle with the exact target libc:

```bash
BIN=./prob_patched LIBC=./libc.so.6 STRATEGY=leak235 CMD='cat flag' \
python3 simple_file_manager_local_exploit_fixed.py
```

---

## Takeaway

The whole challenge comes from one missing line:

```c
current_dir->files[idx] = NULL;
```

Without that, a freed file slot can be recycled as a different object type, leaked as if it were still a file, and then freed again under attacker-controlled metadata. That is enough for heap leak, libc leak, tcache poisoning, arbitrary write, and finally FSOP to `system`.
